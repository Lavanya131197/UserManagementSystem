package com.cg.ums.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.ums.bean.AdminBean;
import com.cg.ums.util.DBConnection;

public class AdmindaoImpl {
	PreparedStatement pst;
    Connection cn;
    ResultSet rs;
	public boolean validate(AdminBean adminbean) throws SQLException {
		
		cn=DBConnection.getInstance().getConnection();
		Statement stmt = cn.createStatement();
		String email=adminbean.getEmail();
		String pass=adminbean.getPassword();
		
		rs=stmt.executeQuery(QueryMapper.ADMIN_LOGIN);
		
		
		
	
		while(rs.next())
		{
			
		
			if(rs.getString(1).equals(email) && rs.getString(2).equals(pass))
			{
				
				return true;
				
			}
		}
		return false;
	}


}
