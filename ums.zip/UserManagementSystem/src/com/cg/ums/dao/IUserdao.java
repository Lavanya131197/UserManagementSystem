package com.cg.ums.dao;

import java.sql.SQLException;

import com.cg.ums.bean.UserBean;

public interface IUserdao {

	public void viewdetails() throws SQLException;
	public void createnewuser(UserBean beanObj) throws SQLException;
	public void editUser(int needEdit, UserBean beanObj) throws SQLException;
	public void deleteDetails(int id) throws SQLException;
}
