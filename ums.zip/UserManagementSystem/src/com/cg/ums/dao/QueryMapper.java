package com.cg.ums.dao;

public interface QueryMapper {
	public static final String ADMIN_LOGIN="SELECT email,password FROM admin_table";
	public static final String RETRIVE_ALL_QUERY="SELECT * FROM users";
	public static final String UPDATE_QUERY="UPDATE users SET email=?,full_name=?,password=? WHERE id=?";
	public static final String INSERT_QUERY="INSERT INTO users VALUES(seq.nextval,index_seq.nextval,?,?,?)";
	public static final String DELETE_QUERY="DELETE FROM users WHERE id=?";
	

}
