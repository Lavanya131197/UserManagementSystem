package com.cg.ums.controller;

import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ums.exception.Userexception;
import com.cg.ums.service.AdminServiceImpl;
import com.cg.ums.service.UserServiceImpl;
public class BookMain {

	static char c;
    static boolean check;
    static String email="";
    static String pass="";
   
    static String mail;
    static String fullName;
    static String password;
	static Scanner sc=new Scanner(System.in);
	static UserServiceImpl userservice=new UserServiceImpl();
	static AdminServiceImpl adminservice=new AdminServiceImpl();
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) throws Userexception, SQLException{
		
		  boolean checking=false;
		PropertyConfigurator.configure("resources//log4j.properties");
		System.out.println("**********Book Store************");
		System.out.println("Book Store Administration");
		
		do {
	
			check=login();
		
		if(check==false)
		{
				System.err.println("Enter valid username and password");
			
		}
		
		
		}while(check==false);
		
		if(check==true)
		{
			do {
			System.out.println("Welcome");
			System.out.println("1. Users \n 2. Categories \n 3. Books \n 4. Customers \n 5. Reviews \n 6.Orders");
			System.out.println("Enter your option");
			int choice=sc.nextInt();
			switch(choice)
			{
			     case 1:
			    {
				   System.out.println("********User Management**********");
				   System.out.println("1.User listening page \n 2.create new user \n 3.Edit user page \n4.Delete user confirmation dialog");
				   System.out.println("Enter your choice");
				   int option=sc.nextInt();
				   switch(option)
				   {
				   case 1:
					userservice.viewdetails();
			        break;
			     
			        
				   case 2:
					   
					   do {
				      System.out.println("Enter Email");
				       mail=sc.next();
				       checking=userservice.isValidEmail(mail);
				       if(checking==false) {
				    	   System.err.println("Entered mail id does not match the pattern");
				    	   System.out.println("Email pattern should contains letters,numbers with some domain like  lavanya@gmail.com or lavanya123@yahoo.com");
				       }
				       }while(checking==false);
					   
					   do {
				      System.out.println("Enter Full name");
				      fullName=sc.next();
				      try {
				      checking=userservice.isValidname(fullName);
				      
				      //checking=true;
				      }
				      catch(Userexception e)
				      {
				    	  System.out.println(e.getMessage());
				    	  checking=false;
				      }
					   }while(checking==false);
					   
					   do {
				      System.out.println("Enter Password");
				      password=sc.next();
				      checking=userservice.isValidPassword(password);
				      if(checking==false)
				      {
				    	  System.err.println("Entered password does not match the pattern");
				    	  System.out.println("password must contain atleast one uppercase letter ,lowercse letter,special character,digits and minimum length 6 and maximum length 16 ");
				      }
					   }while(checking==false);
				      userservice.createnewuser(mail,fullName,password);
				      break;
				      
				      
				   case 3:
					    System.out.println("Edit user page");
					    System.out.println("Enter userid to edit");
						int needEdit=sc.nextInt();
						do {
						      System.out.println("Enter Email");
						       mail=sc.next();
						       checking=userservice.isValidEmail(mail);
						       if(checking==false) {
						    	   System.err.println("Entered mail id does not match the pattern");
						    	   System.out.println("Email pattern should contains letters,numbers with some domain like  lavanya@gmail.com or lavanya123@yahoo.com");
						       }
						       }while(checking==false);
						 do {
						      System.out.println("Enter Full name");
						      fullName=sc.next();
						      try {
						      checking=userservice.isValidname(fullName);
						      
						      //checking=true;
						      }
						      catch(Userexception e)
						      {
						    	  System.out.println(e.getMessage());
						    	  checking=false;
						      }
							   }while(checking==false);
							   
							   
						 do {
						      System.out.println("Enter Password");
						      password=sc.next();
						      checking=userservice.isValidPassword(password);
						      if(checking==false)
						      {
						    	  System.err.println("Entered password does not match the pattern");
						    	  System.out.println("password must contain atleast one uppercase letter ,lowercse letter,special character,digits and minimum length 6 and maximum length 16 ");
						      }
							   }while(checking==false);
						
						userservice.editUser(needEdit,mail,fullName,password);
						break;
			
				   case 4:
					    System.out.println("Delete user");
						System.out.println("Enter user id to delete");
						int id=sc.nextInt();
					try {
						userservice.deleteDetails(id);
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
						
						break;
					}
				}
				    System.out.println("Do you want to continue Y/N");
				    c=sc.next().charAt(0);			    
				} 
				}while(c=='Y');
				System.out.println("********Thank you**********");
			}
			
			
			
			

		}
				private static boolean login() {
					
					System.out.println("Admin Login");
					System.out.println("E-mail:    ");
					email=sc.next();
					System.out.println("Password:  ");
					pass=sc.next();
					boolean check=adminservice.validate(email,pass);
					return check;
				}
				
				
				

}
