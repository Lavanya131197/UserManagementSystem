package com.cg.ums.service;

import java.sql.SQLException;

import com.cg.ums.bean.AdminBean;
import com.cg.ums.dao.AdmindaoImpl;

public class AdminServiceImpl {
	AdminBean adminbean=new AdminBean();
	AdmindaoImpl admindao=new AdmindaoImpl();
	public boolean validate(String email, String pass) {
		
		boolean res = true;
		adminbean.setEmail(email);
		adminbean.setPassword(pass);
		
		 try {
			res=admindao.validate(adminbean);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	return res;
	}

}
