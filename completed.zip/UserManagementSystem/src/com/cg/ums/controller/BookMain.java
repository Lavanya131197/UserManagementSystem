package com.cg.ums.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ums.bean.UserBean;
import com.cg.ums.exception.Userexception;
import com.cg.ums.service.AdminServiceImpl;
import com.cg.ums.service.UserServiceImpl;

public class BookMain {

	static String continueProcess;
	static boolean loginCheck;
	static String adminEmail = "";
	static String adminPassword = "";
	static boolean checking = false;
	static String mail;
	static String fullName;
	static String password;

	static Scanner scanner = new Scanner(System.in);
	static UserServiceImpl userService = new UserServiceImpl();
	static AdminServiceImpl adminService = new AdminServiceImpl();
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Userexception {

		PropertyConfigurator.configure("resources//log4j.properties");
		System.out.println("**********Book Store************");
		System.out.println("Book Store Administration");

		do {

			loginCheck = login();

			if (loginCheck == false) {
				//logger.error("Enter valid username and password");
				System.err.println("Enter valid username and password");
			}

		} while (loginCheck == false);

		if (loginCheck == true) {

			System.out.println("Welcome " + adminEmail);
			System.out.println("********User Management**********");
			do {
				System.out.println("1.User listing page");
				System.out.println("2.create new user");
				System.out.println("3.Edit user page");
				System.out.println("4.Delete user");
				System.out.println("5.Exit");
				int choice;
				boolean choiceFlag = true;
				do {

					try {
						System.out.println("Enter your choice");
						choice = scanner.nextInt();
						choiceFlag = true;

						switch (choice) {

						case 1:
							try {
								List<UserBean> list = userService.viewdetails();

								System.out.println(
										String.format("%-10s %-10s %-20s %s", "Index", "ID", "Email", "FullName"));

								for (UserBean bean : list) {
									System.out.println(String.format("%-10s %-10s %-20s %s", bean.getIndex(),
											bean.getId(), bean.getEmail(), bean.getFullName()));
								}

							} catch (Userexception e1) {
								logger.error(e1.getMessage());
								System.err.println(e1.getMessage());
							}
							break;

						case 2:
							checking = false;
							do {
								System.out.println("Enter Email");
								mail = scanner.next();
								scanner.nextLine();

								try {
									checking = userService.isValidEmail(mail);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Full name");
								fullName = scanner.nextLine();
								try {
									checking = userService.isValidname(fullName);

								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());

								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Password");
								password = scanner.next();
								try {
									checking = userService.isValidPassword(password);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());

								}

							} while (checking == false);
							try {
								int userId = userService.createnewuser(mail, fullName, password);
								if (userId > 0) {
									System.out.println(userId);
									System.out.println("New user created successfully");
								}

							} catch (Userexception e) {
								System.err.println(e.getMessage());
							}
							checking = false;
							break;

						case 3:
							System.out.println("Edit user page");
							boolean validId = false;
							int needEdit = 0;
							do {

								try {
									System.out.println("Enter userid to edit");
									needEdit = scanner.nextInt();
									scanner.nextLine();
									validId = userService.isValidId(needEdit);
								}

								catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								} catch (InputMismatchException e) {
									scanner.nextLine();
									validId = false;
									logger.error("Enter only numbers");
									System.err.println("Enter only numbers");

								}

							} while (validId == false);

							checking = false;

							do {
								System.out.println("Enter Email");

								try {
									mail = scanner.next();
									scanner.nextLine();
									checking = userService.isValidEmail(mail);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								}

							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Full name");
								fullName = scanner.nextLine();
								try {
									checking = userService.isValidname(fullName);

								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
									checking = false;
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Password");
								password = scanner.next();
								try {
									checking = userService.isValidPassword(password);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());

								}

							} while (checking == false);
							checking = false;
							try {
								int updatedRow = userService.editUser(needEdit, mail, fullName, password);
								if (updatedRow == 1)
									System.out.println("details edited successfully");
							} catch (Userexception e) {
								System.err.println(e.getMessage());
							}
							break;

						case 4:
							System.out.println("Delete user");
							boolean validId1 = false;
							int id = 0;

							do {

								System.out.println("Enter userid to delete");

								try {
									id = scanner.nextInt();
									validId1 = userService.isValidId(id);
									validId1 = true;
									System.out.println("Are you sure you want delete the user with id " + id);
									do {
										System.out.println("Enter your choice Yes/No");
										continueProcess = scanner.next();
										if (continueProcess.equalsIgnoreCase("yes")) {
											int deletedRow = userService.deleteDetails(id);
											if (deletedRow == 1)
												System.out.println("User information deleted successfully");

										}
										if (!continueProcess.equalsIgnoreCase("yes")
												&& !continueProcess.equalsIgnoreCase("no"))
											System.err.println("Enter valid option");

									} while (!continueProcess.equalsIgnoreCase("yes")
											&& !continueProcess.equalsIgnoreCase("no"));

								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								} catch (InputMismatchException e) {
									scanner.nextLine();
									validId1 = false;
									logger.error(e.getMessage());
									System.err.println("It should be a number");
								}

							} while (!validId1);

							break;

						case 5:
							System.out.println("*******" + "*Thank you**********");
							return;

						default:
							choiceFlag = false;
							System.err.println("input should be 1, 2 , 3, 4 or 5");
							break;
						}
					} catch (InputMismatchException e) {
						scanner.nextLine();
						choiceFlag = false;
						logger.error("Enter only numbers");
						System.err.println("Enter only numbers");

					}
				} while (!choiceFlag);
				System.out.println(choiceFlag);

				do {
					System.out.println("Do you want to continue Yes/No");
					continueProcess = scanner.next();
					if (!continueProcess.equalsIgnoreCase("yes") && !continueProcess.equalsIgnoreCase("no")) {
						System.err.println("Enter valid option to continue, its case sensitive");
						logger.error("Enter valid option to continue, its case sensitive");
					}
				} while (!continueProcess.equalsIgnoreCase("yes") && !continueProcess.equalsIgnoreCase("no"));

			} while (continueProcess.equalsIgnoreCase("yes"));

			System.out.println("*******" + "*Thank you**********");
		}

	}

	/*******************************************************************************************************
	 * - Function Name 		: login() 
	 * - Input Parameters 	: 
	 * - Return Type 		: boolean
	 * -Throws 				: Userexception
	 * - Author 			: CAPGEMINI 
	 * - Creation Date 		: 24/6/2019
	 * -Descannerription 		: validating Admin calls validate method in adminSeriveImpl
	 ********************************************************************************************************/

	private static boolean login() throws Userexception {

		System.out.println("Admin Login");
		System.out.println("E-mail:    ");
		adminEmail = scanner.nextLine();
		System.out.println("Password:  ");
		adminPassword = scanner.nextLine();
		boolean check;
		check = adminService.validate(adminEmail, adminPassword);
		return check;
	}

}
