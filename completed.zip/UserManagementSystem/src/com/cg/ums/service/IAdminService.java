package com.cg.ums.service;

import com.cg.ums.exception.Userexception;

public interface IAdminService {

	public boolean validate(String email, String pass) throws Userexception;
}
