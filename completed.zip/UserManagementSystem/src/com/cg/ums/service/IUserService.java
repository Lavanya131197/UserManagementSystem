package com.cg.ums.service;

import java.util.List;

import com.cg.ums.bean.UserBean;
import com.cg.ums.exception.Userexception;

public interface IUserService {

	public List<UserBean> viewdetails() throws Userexception;

	public int createnewuser(String mail, String fullName, String password) throws Userexception;

	public int editUser(int needEdit, String mailId, String name, String pwd) throws Userexception;

	public int deleteDetails(int id) throws Userexception;

	public boolean isValidEmail(String mail) throws Userexception;

	public boolean isValidname(String fullName) throws Userexception;

	public boolean isValidPassword(String password) throws Userexception;

	public boolean isValidId(int needEdit) throws Userexception;
}
