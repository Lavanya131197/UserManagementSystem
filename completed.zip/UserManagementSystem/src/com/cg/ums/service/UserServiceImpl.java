package com.cg.ums.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ums.bean.UserBean;
import com.cg.ums.dao.UserdaoImpl;
import com.cg.ums.exception.Userexception;

public class UserServiceImpl implements IUserService {
	UserdaoImpl udao = new UserdaoImpl();
	UserBean beanObj = new UserBean();

		/*******************************************************************************************************
		 - Function Name	:	List<UserBean> viewdetails()
		 - Input Parameters	:	
		 - Return Type		:	List<UserBean>
		 - Throws			:  	Userexception
		 - Author			:	CAPGEMINI
		 - Creation Date	:	24/6/2019
		 - Description		:	Retrieving all user details from the database calls dao method viewdetails()
		 ********************************************************************************************************/
	public List<UserBean> viewdetails() throws Userexception {

		return udao.viewdetails();
	}
	
			/*******************************************************************************************************
			 - Function Name	:	createnewuser(String mail, String fullName, String password)
			 - Input Parameters	:	mail,fullName,password
			 - Return Type		:	int
			 - Throws			:  	Userexception
			 - Author			:	CAPGEMINI
			 - Creation Date	:	24/6/2019
			 - Description		:	adding users to database calls dao method createnewuser(beanObj)
			 ********************************************************************************************************/
	

	public int createnewuser(String mail, String fullName, String password) throws Userexception {

		beanObj.setEmail(mail);
		beanObj.setFullName(fullName);
		beanObj.setPassword(password);
		int userId = udao.createnewuser(beanObj);
		return userId;

	}
	
	/*******************************************************************************************************
	 - Function Name	:	editUser(int needEdit, String mailId, String name, String pwd)
	 - Input Parameters	:	needEdit,mail,fullName,password
	 - Return Type		:	int
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	Edit users detaiils in database calls dao method editUser(needEdit,beanObj)
	 ********************************************************************************************************/


	public int editUser(int needEdit, String mailId, String name, String pwd) throws Userexception {

		beanObj.setEmail(mailId);
		beanObj.setFullName(name);
		beanObj.setPassword(pwd);
		return udao.editUser(needEdit, beanObj);

	}
	
	
		/*******************************************************************************************************
		 - Function Name	:	deleteDetails(int id)
		 - Input Parameters	:	id
		 - Return Type		:	int
		 - Throws			:  	Userexception
		 - Author			:	CAPGEMINI
		 - Creation Date	:	24/6/2019
		 - Description		:	Delete users detaiils in database calls dao method deleteDetails(id)
		 ********************************************************************************************************/

	public int deleteDetails(int id) throws Userexception {

		return udao.deleteDetails(id);

	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	isValidEmail(String mail)
	 - Input Parameters	:	mail
	 - Return Type		:	boolean
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	validating User Email
	 ********************************************************************************************************/


	public boolean isValidEmail(String mail) throws Userexception {

		Pattern namePattern = Pattern.compile(
				"^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
		Matcher nameMatcher = namePattern.matcher(mail);
		if (!nameMatcher.matches())
			throw new Userexception(
					"Email pattern should contains letters,numbers with some domain like  lavanya@gmail.com or lavanya123@yahoo.com");
		return nameMatcher.matches();
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	isValidname(String fullName)
	 - Input Parameters	:	fullName
	 - Return Type		:	boolean
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	validating User Name
	 ********************************************************************************************************/

	public boolean isValidname(String fullName) throws Userexception {

		Pattern namePattern = Pattern.compile("^[A-Z]{1}[a-zA-Z ]{3,30}$");
		Matcher nameMatcher = namePattern.matcher(fullName);

		if (!nameMatcher.matches())
			throw new Userexception("first letter should be capital ,combination of lowercase & uppercase letter only and length must be in between 4 to 15");
		else
			return nameMatcher.matches();
	}

	/*******************************************************************************************************
	 - Function Name	:	isValidPassword(String password)
	 - Input Parameters	:	password
	 - Return Type		:	boolean
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	validating User Password
	 ********************************************************************************************************/

	public boolean isValidPassword(String password) throws Userexception {

		Pattern namePattern = Pattern.compile("^(?=(.*[a-z]){1,})(?=(.*[\\d]){1,})(?=(.*[\\W]){1,})(?!.*\\s).{7,30}$");
		Matcher nameMatcher = namePattern.matcher(password);
		if (!nameMatcher.matches())
			throw new Userexception(
					"password must contain  at least 1 lower case, 1 upper case, 1 numeric, 1 non-word and no whitespace");
		else
			return nameMatcher.matches();
	}
	

	/*******************************************************************************************************
	 - Function Name	:	isValidId(int needEdit)
	 - Input Parameters	:	needEdit
	 - Return Type		:	boolean
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	validating existing id call dao method isValidId(int needEdit)
	 ********************************************************************************************************/


	public boolean isValidId(int needEdit) throws Userexception {

		return udao.isValidId(needEdit);
	}

}
