package com.cg.ums.service;

import com.cg.ums.bean.AdminBean;
import com.cg.ums.dao.AdmindaoImpl;
import com.cg.ums.exception.Userexception;

public class AdminServiceImpl implements IAdminService{
	AdminBean adminbean = new AdminBean();
	AdmindaoImpl admindao = new AdmindaoImpl();
	 
	/*******************************************************************************************************
	 - Function Name	:	validate(String email, String password)
	 - Input Parameters	:	email,password
	 - Return Type		:	boolean
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	validating Admin
	 ********************************************************************************************************/

	public boolean validate(String email, String password) throws Userexception {

		boolean res = true;
		adminbean.setEmail(email);
		adminbean.setPassword(password);
		res = admindao.validate(adminbean);

		return res;
	}

}
