package com.cg.ums.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.ums.bean.UserBean;
import com.cg.ums.exception.Userexception;
import com.cg.ums.util.DBConnection;

public class UserdaoImpl implements IUserdao{
	static Scanner sc = new Scanner(System.in);
	PreparedStatement preparedStatement = null;
	Connection connection = null;
	ResultSet resultSet = null;

	Logger logger = Logger.getRootLogger();
	 
		/*******************************************************************************************************
		 - Function Name	:	viewdetails()
		 - Input Parameters	:	
		 - Return Type		:	List<UserBean>
		 - Throws			:  	Userexception
		 - Author			:	CAPGEMINI
		 - Creation Date	:	24/6/2019
		 - Description		:	Retrieving all users 
		 ********************************************************************************************************/

	public List<UserBean> viewdetails() throws Userexception {
		List<UserBean> list = new ArrayList<>();
		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				UserBean userbean = new UserBean();
				userbean.setIndex(resultSet.getString(1));
				userbean.setId(resultSet.getString(2));
				userbean.setEmail(resultSet.getString(3));
				userbean.setFullName(resultSet.getString(4));

				list.add(userbean);
			}
			return list;
		} catch (SQLException sqlexception) {
			logger.error(sqlexception.getMessage());
			throw new Userexception("Problem occured while retrieving the values from table");
		}
		finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
		

	}
	 
			/*******************************************************************************************************
			 - Function Name	:	createnewuser(UserBean beanObj)
			 - Input Parameters	:	
			 - Return Type		:	int
			 - Throws			:  	Userexception
			 - Author			:	CAPGEMINI
			 - Creation Date	:	24/6/2019
			 - Description		:	Create new User 
			 ********************************************************************************************************/

	public int createnewuser(UserBean beanObj) throws Userexception {

		connection = DBConnection.getConnection();

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
			String em = beanObj.getEmail();
			String fn = beanObj.getFullName();
			String pass = beanObj.getPassword();
			preparedStatement.setString(1, em);
			preparedStatement.setString(2, fn);
			preparedStatement.setString(3, pass);
			preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.CURR_VAL);
			resultSet = preparedStatement.executeQuery();
			int userid = 0;
			while (resultSet.next()) {
				userid = resultSet.getInt(1);
			}
			
			return userid;
		} catch (SQLException sqlexception) {
			logger.error(sqlexception.getMessage());
			throw new Userexception("Exception occured while creating new user");
		}
		finally {
			try {
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
		

	}

	 
	/*******************************************************************************************************
	 - Function Name	:	editUser(int needEdit, UserBean beanObj)
	 - Input Parameters	:	needEdit,beanObj
	 - Return Type		:	int
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	Edit user details 
	 ********************************************************************************************************/
	
	public int editUser(int needEdit, UserBean beanObj) throws Userexception {

		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_QUERY);
			preparedStatement.setString(1, beanObj.getEmail());
			preparedStatement.setString(2, beanObj.getFullName());
			preparedStatement.setString(3, beanObj.getPassword());
			preparedStatement.setInt(4, needEdit);
			int updatedRow = preparedStatement.executeUpdate();
			return updatedRow;

		} catch (SQLException sqlexception) {

			logger.error(sqlexception.getMessage());
			throw new Userexception("Email id already exits");
		}
		finally {
			try {
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
		

	}
	 
		/*******************************************************************************************************
		 - Function Name	:	deleteDetails(int id)
		 - Input Parameters	:	id
		 - Return Type		:	int
		 - Throws			:  	Userexception
		 - Author			:	CAPGEMINI
		 - Creation Date	:	24/6/2019
		 - Description		:	Delete user details 
		 ********************************************************************************************************/

	public int deleteDetails(int id) throws Userexception {

		int val = 0;
		connection = DBConnection.getConnection();

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_QUERY);
			preparedStatement.setInt(1, id);
			val = preparedStatement.executeUpdate();
			return val;

		} catch (SQLException sqlexception) {
			logger.error(sqlexception.getMessage());
			throw new Userexception("Exception occured while deleting the data");
		}
		finally {
			try {
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
	

	}
	 
			/*******************************************************************************************************
			 - Function Name	:	isValidId(int needEdit)
			 - Input Parameters	:	needEdit
			 - Return Type		:	boolean
			 - Throws			:  	Userexception
			 - Author			:	CAPGEMINI
			 - Creation Date	:	24/6/2019
			 - Description		:	Checks whether particular user id present or not
			 ********************************************************************************************************/

	public boolean isValidId(int needEdit) throws  Userexception {

		connection = DBConnection.getConnection();
		int value = 0;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.RETRIVE_PARTICULAR_ID);
			preparedStatement.setInt(1, needEdit);
			value = preparedStatement.executeUpdate();
			if (value == 1)
				return true;
			else
				throw new Userexception("Invalid id");
		} catch (SQLException sqlexception) {
			logger.error(sqlexception.getMessage());
			throw new Userexception("Exception occured while retrieving the id");
		}
		finally {
			try {
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
		

	}

}
