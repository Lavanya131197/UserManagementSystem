package com.cg.ums.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.ums.bean.AdminBean;
import com.cg.ums.exception.Userexception;
import com.cg.ums.util.DBConnection;

public class AdmindaoImpl {

	Connection connection;
	ResultSet rs;
	PreparedStatement preparedStatement;
	static Logger logger = Logger.getRootLogger();

	 
			/*******************************************************************************************************
			 - Function Name	:	validate(AdminBean adminbean)
			 - Input Parameters	:	
			 - Return Type		:	boolean
			 - Throws			:  	Userexception
			 - Author			:	CAPGEMINI
			 - Creation Date	:	24/6/2019
			 - Description		:	validating Admin
			 ********************************************************************************************************/
	
	public boolean validate(AdminBean adminbean) throws Userexception {

		connection = DBConnection.getConnection();
		
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.ADMIN_LOGIN);
            preparedStatement.setString(1, adminbean.getEmail());
            preparedStatement.setString(2, adminbean.getPassword());
			rs = preparedStatement.executeQuery();
			while (rs.next()) {

				
					return true;

				
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			System.out.println("Problem occured while validating admin");
		}

		finally {
			try {
				rs.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
		return false;

	}

}
