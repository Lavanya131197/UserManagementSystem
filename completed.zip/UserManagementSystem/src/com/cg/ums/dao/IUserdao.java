package com.cg.ums.dao;

import java.util.List;

import com.cg.ums.bean.UserBean;
import com.cg.ums.exception.Userexception;

public interface IUserdao {

	public List<UserBean> viewdetails() throws Userexception;

	public int createnewuser(UserBean beanObj) throws Userexception;

	public int editUser(int needEdit, UserBean beanObj) throws Userexception;

	public int deleteDetails(int id) throws Userexception;

	public boolean isValidId(int needEdit) throws Userexception;
}
