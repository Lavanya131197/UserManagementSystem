package com.cg.ums.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.ums.exception.Userexception;

public class DBConnection {
	private static Connection connection = null;
	
	
	/*******************************************************************************************************
	 - Function Name	:	getConnection()
	 - Input Parameters	:	
	 - Return Type		:	Connection
	 - Throws			:  	Userexception
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/6/2019
	 - Description		:	Loads the  jdbc.properties file and Driver Class and gets the connection
	 ********************************************************************************************************/

	 
	
	
	
	public static Connection getConnection() throws Userexception {
 
		File file = new File("resources/jdbc.properties");
		FileInputStream inputStream = null;
		Properties properties = new Properties();
 
		try {
			inputStream = new FileInputStream(file);
			properties.load(inputStream);
 
			String driver = properties.getProperty("driver");
			String url = properties.getProperty("dburl");
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");
 
 
			Class.forName(driver);
 
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("done");
 
		} catch (FileNotFoundException e) {
			throw new Userexception("unable to create file object");
		} catch (IOException e) {
			throw new Userexception("unable to load the data");
		} catch (ClassNotFoundException e) {
			throw new Userexception("problem occured while loading the driver");
		} catch (SQLException e) {
			throw new Userexception("problem occured while establishing the connection");
		}
 
		return connection;
 
	}
}
