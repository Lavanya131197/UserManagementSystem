package com.cg.ums.dao.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ums.bean.UserBean;
import com.cg.ums.dao.UserdaoImpl;
import com.cg.ums.exception.Userexception;

public class UserdaoITest {

	UserdaoImpl daoImpl = null;

	@Before
	public void setUp() throws Exception {
		daoImpl = new UserdaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}

	@Test
	public void testAddUser() {

		UserBean userbean = new UserBean("balki@gmail.com", "Balki", "Vasundara@%1");

		try {
			int genId = daoImpl.createnewuser(userbean);
			assertNotNull(genId);

		} catch (Userexception e) {

		}
	}

	@Test
	public void viewDetails() throws Userexception {
		List<UserBean> list = daoImpl.viewdetails();
		assertTrue(list.size() > 0);
	}

	@Test
	public void editDetails() throws Userexception {
		UserBean bean = new UserBean();
		bean.setEmail("manjula@gmail.com");
		bean.setFullName("Manjula Devi");
		bean.setPassword("Manjula)(1");
		int value = daoImpl.editUser(240, bean);
		System.out.println(value);
		assertTrue(value == 1);
	}

	@Test
	public void deleteUser() throws Userexception {
		int value = daoImpl.deleteDetails(238);
		System.out.println(value);
		assertTrue(value == 1);
	}

}
