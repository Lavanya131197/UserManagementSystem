package com.cg.ums.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ums.bean.UserBean;
import com.cg.ums.exception.Userexception;
import com.cg.ums.service.AdminServiceImpl;
import com.cg.ums.service.UserServiceImpl;

public class BookMain {

	static String continueProcess;
	static boolean loginCheck;
	static String adminEmail = "";
	static String adminPassword = "";
	static boolean checking = false;
	static String mail;
	static String fullName;
	static String password;

	static Scanner sc = new Scanner(System.in);
	static UserServiceImpl userService = new UserServiceImpl();
	static AdminServiceImpl adminService = new AdminServiceImpl();
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Userexception {

		PropertyConfigurator.configure("resources//log4j.properties");
		System.out.println("**********Book Store************");
		System.out.println("Book Store Administration");
		/*
		 * Admin login 
		 * */

		do {

			loginCheck = login();

			if (loginCheck == false) {
				logger.error("Enter valid username and password");
				System.err.println("Enter valid username and password");
			}

		} while (loginCheck == false);

		if (loginCheck == true) {

			System.out.println("Welcome " + adminEmail);
			System.out.println("********User Management**********");
			do {
				System.out.println(
						"1.User listening page \n 2.create new user \n 3.Edit user page \n4.Delete user confirmation dialog \n 5.Exit");
				int option;
				boolean choiceFlag = true;
				do {

					try {
						System.out.println("Enter your choice");
						option = sc.nextInt();
						choiceFlag = true;
						// sc.nextLine();
						switch (option) {
						
						
						
						/*Switch case to view all the user details in the Book Management System*/
						case 1:
							try {
								List<UserBean> list = userService.viewdetails();

								System.out.println(
										String.format("%-10s %-10s %-20s %s", "Index", "ID", "Email", "FullName"));

								for (UserBean bean : list) {
									System.out.println(String.format("%-10s %-10s %-20s %s", bean.getIndex(),
											bean.getId(), bean.getEmail(), bean.getFullName()));
								}

							} catch (Userexception e1) {
								System.err.println(e1.getMessage());
							}
							break;
							
							/*Switch case to create the new user account*/

						case 2:
							checking = false;
							do {
								System.out.println("Enter Email");
								mail = sc.next();
								sc.nextLine();

								try {
									checking = userService.isValidEmail(mail);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Full name");
								fullName = sc.nextLine();
								try {
									checking = userService.isValidname(fullName);

								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());

								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Password");
								password = sc.next();
								try {
									checking = userService.isValidPassword(password);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());

								}

							} while (checking == false);
							try {
								int userId = userService.createnewuser(mail, fullName, password);
								if (userId > 0) {
									System.out.println("New user created successfully");
								}

							} catch (Userexception e) {
								System.err.println(e.getMessage());
							}
							checking = false;
							break;
							/*Switch case to edit the user details*/

						case 3:
							System.out.println("Edit user page");
							boolean validId = false;
							int needEdit;
							do {

								System.out.println("Enter userid to edit");
								needEdit = sc.nextInt();
								sc.nextLine();
								try {
									validId = userService.isValidId(needEdit);
								}

								catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								}

							} while (validId == false);

							checking = false;

							do {
								System.out.println("Enter Email");
								mail = sc.next();
								sc.nextLine();
								try {
									checking = userService.isValidEmail(mail);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Full name");
								fullName = sc.nextLine();
								try {
									checking = userService.isValidname(fullName);

									// checking=true;
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
									checking = false;
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Password");
								password = sc.next();
								try {
									checking = userService.isValidPassword(password);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());

								}

							} while (checking == false);
							checking = false;
							try {
								int updatedRow = userService.editUser(needEdit, mail, fullName, password);
								if (updatedRow == 1)
									System.out.println("details edited successfully");
							} catch (Userexception e) {
								System.err.println(e.getMessage());
							}
							break;
							/*Switch case to delete the user details*/

						case 4:
							System.out.println("Delete user");
							boolean validId1 = false;
							int id = 0;

							do {

								System.out.println("Enter userid to delete");

								try {
									id = sc.nextInt();
									validId1 = userService.isValidId(id);
									validId1 = true;
									System.out.println("Are you sure you want delete the user with id " + id);
									do {
										System.out.println("Enter your choice Yes/No");
										continueProcess = sc.next();
										if (continueProcess.equalsIgnoreCase("yes")) {
											int deletedRow = userService.deleteDetails(id);
											if (deletedRow == 1)
												System.out.println("User information deleted successfully");

										}
										if (!continueProcess.equalsIgnoreCase("yes")
												&& !continueProcess.equalsIgnoreCase("no"))
											System.err.println("Enter valid option");

									} while (!continueProcess.equalsIgnoreCase("yes")
											&& !continueProcess.equalsIgnoreCase("no"));

								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								} catch (InputMismatchException e) {
									sc.nextLine();
									validId1 = false;
									logger.error(e.getMessage());
									System.err.println("It should be a number");
								}

							} while (!validId1);
							

							break;
							
							/*Switch case to exit from the application*/
						case 5:
							System.out.println("*******" + "*Thank you**********");
							return;
							
						default:
							choiceFlag = false;
							System.err.println("input should be 1, 2 , 3, 4 or 5");
							break;
						}
					} catch (InputMismatchException e) {
						sc.nextLine();
						choiceFlag = false;
						logger.error("Enter only numbers");
						System.err.println("Enter only numbers");

					}
				} while (!choiceFlag);
				System.out.println(choiceFlag);
				
				/**/
				do {
					System.out.println("Do you want to continue Yes/No");
					continueProcess = sc.next();
					if (!continueProcess.equalsIgnoreCase("yes") && !continueProcess.equalsIgnoreCase("no")) {
						System.err.println("Enter valid option to continue, its case sensitive");
						logger.error("Enter valid option to continue, its case sensitive");
					}
				} while (!continueProcess.equalsIgnoreCase("yes") && !continueProcess.equalsIgnoreCase("no"));

			} while (continueProcess.equalsIgnoreCase("yes"));

			System.out.println("*******" + "*Thank you**********");
		}

	}
	/*Admin login method
	 */

	private static boolean login() throws Userexception {

		System.out.println("Admin Login");
		System.out.println("E-mail:    ");
		adminEmail = sc.nextLine();
		System.out.println("Password:  ");
		adminPassword = sc.nextLine();
		boolean check;
		check = adminService.validate(adminEmail, adminPassword);
		return check;
	}

}
