package com.cg.ums.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ums.bean.UserBean;
import com.cg.ums.dao.UserdaoImpl;
import com.cg.ums.exception.Userexception;

public class UserServiceImpl implements IUserService {
	UserdaoImpl udao = new UserdaoImpl();
	UserBean beanObj = new UserBean(null, null, null);

	public List<UserBean> viewdetails() throws Userexception {

		return udao.viewdetails();

	}

	public int createnewuser(String mail, String fullName, String password) throws Userexception {

		beanObj.setEmail(mail);
		beanObj.setFullName(fullName);
		beanObj.setPassword(password);
		int userId = udao.createnewuser(beanObj);
		return userId;

	}

	public int editUser(int needEdit, String mailId, String name, String pwd) throws Userexception {

		beanObj.setEmail(mailId);
		beanObj.setFullName(name);
		beanObj.setPassword(pwd);
		return udao.editUser(needEdit, beanObj);

	}

	public int deleteDetails(int id) throws Userexception {

		return udao.deleteDetails(id);

	}

	public boolean isValidEmail(String mail) throws Userexception {

		Pattern namePattern = Pattern.compile(
				"^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
		Matcher nameMatcher = namePattern.matcher(mail);
		if (!nameMatcher.matches())
			throw new Userexception(
					"Email pattern should contains letters,numbers with some domain like  lavanya@gmail.com or lavanya123@yahoo.com");
		return nameMatcher.matches();
	}

	public boolean isValidname(String fullName) throws Userexception {

		Pattern namePattern = Pattern.compile("^[A-Z]{1}[a-zA-Z ]{3,30}$");
		Matcher nameMatcher = namePattern.matcher(fullName);

		if (!nameMatcher.matches())
			throw new Userexception("first letter should be capital and length must be in between 4 to 15");
		else
			return nameMatcher.matches();
	}

	public boolean isValidPassword(String password) throws Userexception {

		Pattern namePattern = Pattern.compile("^((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})$");
		Matcher nameMatcher = namePattern.matcher(password);
		if (!nameMatcher.matches())
			throw new Userexception(
					"password must contain atleast one uppercase letter ,lowercse letter,special character,digits and minimum length 6 and maximum length 20");
		else
			return nameMatcher.matches();
	}

	public boolean isValidId(int needEdit) throws Userexception {

		return udao.isValidId(needEdit);
	}

}
