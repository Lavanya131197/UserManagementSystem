package com.cg.ums.exception;

@SuppressWarnings("serial")
public class Userexception extends Exception {

	public Userexception(String message) {
		super(message);

	}

}
