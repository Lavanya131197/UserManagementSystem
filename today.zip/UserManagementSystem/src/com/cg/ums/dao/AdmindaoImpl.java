package com.cg.ums.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.cg.ums.bean.AdminBean;
import com.cg.ums.exception.Userexception;
import com.cg.ums.util.DBConnection;

public class AdmindaoImpl {

	Connection cn;
	ResultSet rs;
	static Logger logger = Logger.getRootLogger();

	public boolean validate(AdminBean adminbean) throws Userexception {

		cn = DBConnection.getInstance().getConnection();
		Statement stmt;
		String email = "";
		String pass = "";
		try {
			stmt = cn.createStatement();
			email = adminbean.getEmail();
			pass = adminbean.getPassword();

			rs = stmt.executeQuery(QueryMapper.ADMIN_LOGIN);
		} catch (SQLException e) {
			logger.error(e.getMessage());
			System.out.println("Check logger file");
		}

		try {
			while (rs.next()) {

				if (rs.getString(1).equals(email) && rs.getString(2).equals(pass)) {

					return true;

				}
			}
		} catch (SQLException e) {

			logger.error(e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				//pst.close();
				cn.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new Userexception("Error in closing db connection");

			}
		}
		return false;
		
		
	}

}
