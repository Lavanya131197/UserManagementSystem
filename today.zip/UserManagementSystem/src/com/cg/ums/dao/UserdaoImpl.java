package com.cg.ums.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Logger;
import com.cg.ums.bean.UserBean;
import com.cg.ums.exception.Userexception;
import com.cg.ums.util.DBConnection;


public class UserdaoImpl {
	static Scanner sc=new Scanner(System.in);
	PreparedStatement pst=null;
    Connection cn=null;
    ResultSet rs=null;
    Statement stmt=null;
    
    Logger logger=Logger.getRootLogger();
	public void viewdetails() throws Userexception {
		
		cn=DBConnection.getInstance().getConnection();
			try {
				stmt = cn.createStatement();
				rs=stmt.executeQuery(QueryMapper.RETRIVE_ALL_QUERY);
				while(rs.next())
				{
					System.out.println("Index:"+rs.getInt(1));
					System.out.println("Id: "+rs.getInt(2));
					System.out.println("Email: "+rs.getString(3));
					System.out.println("Full Name: "+rs.getString(4));
					System.out.println("Password: "+rs.getString(5));
				}
			} catch (SQLException sqlexception) {
				// TODO Auto-generated catch block
				sqlexception.printStackTrace();
				logger.error(sqlexception.getMessage());
				throw new Userexception("Tehnical problem occured refer log");
				
			}
			
		
		
	}
	
	
	public int createnewuser(UserBean beanObj) throws Userexception {
		
		 cn=DBConnection.getInstance().getConnection();
		  
			try {
				pst = cn.prepareStatement(QueryMapper.INSERT_QUERY);
				String em=beanObj.getEmail();
				String fn=beanObj.getFullName();
				String pass=beanObj.getPassword();
				pst.setString(1, em);
				pst.setString(2, fn);
				pst.setString(3, pass);
				pst.executeUpdate();
				pst=cn.prepareStatement(QueryMapper.CURR_VAL);
				rs=pst.executeQuery();
				int userid=0;
				while(rs.next())
				{
					userid=rs.getInt(1);
				}
				System.out.println("New user profile created successfully");
				return userid;
			} catch (SQLException sqlexception) {
				logger.error("Primary constraints violated");
				throw new Userexception("Tehnical problem occured refer log");
			}
			
		
	}
	public void editUser(int needEdit, UserBean beanObj) throws Userexception {
		
		cn=DBConnection.getInstance().getConnection();
		try {
			pst = cn.prepareStatement(QueryMapper.UPDATE_QUERY);
			pst.setString(1, beanObj.getEmail());
			pst.setString(2, beanObj.getFullName());
			pst.setString(3, beanObj.getPassword());
			pst.setInt(4, needEdit);
			pst.executeQuery();
			System.out.println("details edited successfully");
		} catch (SQLException sqlexception) {
			
			
			logger.error("Primary constraints violated");
			throw new Userexception("Tehnical problem occured refer log");
		}
		
		
	}
	public void deleteDetails(int id) throws Userexception {
		
		int val;
		cn=DBConnection.getInstance().getConnection();
		
		try {
			pst = cn.prepareStatement(QueryMapper.DELETE_QUERY);
			pst.setInt(1, id);
			System.out.println("Are you sure you want delete the user with id "+id);
			System.out.println("Enter your choice Y/N");
			char ch=sc.next().charAt(0);
			if(ch=='Y') {
			 val=pst.executeUpdate();
		
			}
			else
				return;
			if(val==1)
			{
				System.out.println("User details deleted successfully");
			}
			else
			{
				System.out.println("User details does not exists");
			}
			
		} catch (SQLException sqlexception) {
			
			sqlexception.printStackTrace();
			logger.error(sqlexception.getMessage());
			throw new Userexception("Tehnical problem occured refer log");
		}
		
	}


	public boolean isValidId(int needEdit) throws SQLException, Userexception {
		// TODO Auto-generated method stub
		cn=DBConnection.getInstance().getConnection();
		int value=0;
		try {
			pst=cn.prepareStatement(QueryMapper.RETRIVE_PARTICULAR_ID);
			pst.setInt(1, needEdit);
			value=pst.executeUpdate();
		} catch (SQLException sqlexception) {
			// TODO Auto-generated catch block
			sqlexception.printStackTrace();
			logger.error(sqlexception.getMessage());
		}
		
		if(value==1)
			return true;
		else
		    throw new Userexception("Invalid id");
	}

}
