package com.cg.ums.service;

import java.sql.SQLException;

public interface IUserService {

	public void viewdetails();
	public void createnewuser(String mail, String fullName, String password);
	public void editUser(int needEdit, String mailId, String name, String pwd);
	public void deleteDetails(int id) throws SQLException;
}
