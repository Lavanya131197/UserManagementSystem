package com.cg.ums.service;

import java.sql.SQLException;

import com.cg.ums.exception.Userexception;

public interface IUserService {

	public void viewdetails();

	public void createnewuser(String mail, String fullName, String password);

	public void editUser(int needEdit, String mailId, String name, String pwd);

	public void deleteDetails(int id) throws SQLException;

	public boolean isValidEmail(String mail) throws Userexception;

	public boolean isValidname(String fullName) throws Userexception;

	public boolean isValidPassword(String password) throws Userexception;

	public boolean isValidId(int needEdit) throws Userexception, SQLException;
}
