package com.cg.ums.service;

public interface IAdminService {

	public boolean validate(String email, String pass);
}
