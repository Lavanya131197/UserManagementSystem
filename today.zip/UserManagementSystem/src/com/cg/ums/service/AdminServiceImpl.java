package com.cg.ums.service;

import java.sql.SQLException;

import com.cg.ums.bean.AdminBean;
import com.cg.ums.dao.AdmindaoImpl;

public class AdminServiceImpl {
	AdminBean adminbean=new AdminBean();
	AdmindaoImpl admindao=new AdmindaoImpl();
	public boolean validate(String email, String pass) throws SQLException {
		
		boolean res = true;
		adminbean.setEmail(email);
		adminbean.setPassword(pass);
		
		 res=admindao.validate(adminbean);
		
	return res;
	}

}
