package com.cg.ums.controller;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.omg.CORBA.UserException;

import com.cg.ums.exception.Userexception;
import com.cg.ums.service.AdminServiceImpl;
import com.cg.ums.service.UserServiceImpl;

public class BookMain {

	static char c;
	static boolean check;
	static String email = "";
	static String pass = "";
	static boolean checking = false;
	static String mail;
	static String fullName;
	static String password;

	static Scanner sc = new Scanner(System.in);
	static UserServiceImpl userservice = new UserServiceImpl();
	static AdminServiceImpl adminservice = new AdminServiceImpl();
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Userexception {

		PropertyConfigurator.configure("resources//log4j.properties");
		System.out.println("**********Book Store************");
		System.out.println("Book Store Administration");

		do {

			try {
				check = login();

			} catch (SQLException e) {
				throw new Userexception("Enter valid userid and password"); 
				//e.printStackTrace();
			}

			if (check == false) {
				logger.error("Enter valid username and password");
				System.err.println("Enter valid username and password");
			}

		} while (check == false);

		if (check == true) {

			// boolean checking=false;
			System.out.println("Welcome " + email);
			System.out.println("********User Management**********");
			do {
				System.out.println(
						"1.User listening page \n 2.create new user \n 3.Edit user page \n4.Delete user confirmation dialog \n 5.Exit");
				int option;
				boolean choiceFlag = true;
				do {

					try {
						System.out.println("Enter your choice");
						option = sc.nextInt();
						choiceFlag = true;
						// sc.nextLine();
						switch (option) {
						case 1:
							try {
								userservice.viewdetails();
							} catch (SQLException e1) {

								e1.printStackTrace();
							}
							break;

						case 2:
							checking = false;
							do {
								System.out.println("Enter Email");
								// sc.nextLine();
								mail = sc.next();
								sc.nextLine();

								try {
									checking = userservice.isValidEmail(mail);
								} catch (Userexception e) {
									System.out.println(e.getMessage());
									// checking=false;
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Full name");
								fullName = sc.nextLine();
								try {
									checking = userservice.isValidname(fullName);

								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.out.println(e.getMessage());
									// checking=false;
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Password");
								password = sc.next();
								try {
									checking = userservice.isValidPassword(password);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.out.println(e.getMessage());

								}

							} while (checking == false);
							try {
								int userId = userservice.createnewuser(mail, fullName, password);

							} catch (Userexception e) {
								System.err.println("Refer log file");
							}
							checking = false;
							break;

						case 3:
							System.out.println("Edit user page");
							boolean validId = false;
							int needEdit;
							do {

								System.out.println("Enter userid to edit");
								needEdit = sc.nextInt();
								sc.nextLine();
								try {
									validId = userservice.isValidId(needEdit);
								}

								catch (Userexception e) {
									logger.error(e.getMessage());
									System.out.println(e.getMessage());
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							} while (validId == false);

							checking = false;

							do {
								System.out.println("Enter Email");
								// sc.nextLine();
								mail = sc.next();
								sc.nextLine();
								try {
									checking = userservice.isValidEmail(mail);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.out.println(e.getMessage());
									// checking=false;
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Full name");
								fullName = sc.nextLine();
								try {
									checking = userservice.isValidname(fullName);

									// checking=true;
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.out.println(e.getMessage());
									checking = false;
								}
							} while (checking == false);

							checking = false;

							do {
								System.out.println("Enter Password");
								password = sc.next();
								try {
									checking = userservice.isValidPassword(password);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.out.println(e.getMessage());

								}

							} while (checking == false);
							checking = false;
							userservice.editUser(needEdit, mail, fullName, password);
							break;

						case 4:
							System.out.println("Delete user");
							validId = false;
							int id;
							do {

								System.out.println("Enter userid to delete");
								id = sc.nextInt();
								try {
									validId = userservice.isValidId(id);
								} catch (Userexception e) {
									logger.error(e.getMessage());
									System.err.println(e.getMessage());
								} catch (SQLException e) {
								
									e.printStackTrace();
								}

							} while (validId == false);

							try {
								userservice.deleteDetails(id);
							} catch (SQLException e) {

								e.printStackTrace();
								logger.error(e.getMessage());
							}

							break;
						case 5:
							System.out.println("*******" + "*Thank you**********");
							return;
						default:
							choiceFlag = false;
							System.out.println("input should be 1, 2 , 3, 4 or 5");
							break;
						}
					} catch (InputMismatchException e) {
						sc.nextLine();
						choiceFlag = false;
						logger.error("Enter only numbers");
						System.err.println("Enter only numbers");
						// System.out.println(choiceFlag);

					}
				} while (!choiceFlag);

				do {
					System.out.println("Do you want to continue Y/N");
					c = sc.next().charAt(0);
					if (c != 'Y' && c != 'N') {
						System.err.println("Enter valid option to continue, its case sensitive");
						logger.error("Enter valid option to continue, its case sensitive");
					}
				} while (c != 'Y' && c != 'N');

			} while (c == 'Y');

			System.out.println("*******" + "*Thank you**********");
		}

	}

	private static boolean login() throws SQLException, Userexception {

		System.out.println("Admin Login");
		System.out.println("E-mail:    ");
		email = sc.nextLine();
		System.out.println("Password:  ");
		pass = sc.nextLine();
		boolean check = adminservice.validate(email, pass);
		return check;
	}

}
