 CREATE TABLE users(index_no NUMBER,id NUMBER,email VARCHAR(20) primary key,full_name VARCHAR(20),password VARCHAR(15));
 
 CREATE TABLE admin_table(email VARCHAR(20) PRIMARY KEY,password VARCHAR(15));