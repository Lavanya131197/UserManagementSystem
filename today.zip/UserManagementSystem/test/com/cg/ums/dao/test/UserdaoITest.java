package com.cg.ums.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ums.bean.UserBean;
import com.cg.ums.dao.UserdaoImpl;
import com.cg.ums.exception.Userexception;



public class UserdaoITest {
	
	UserdaoImpl daoImpl = null;
	
	@Before
	public void setUp() throws Exception {
		daoImpl = new UserdaoImpl();
	}
	
	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}
	
	@Test
	public void testAddUser() {

		UserBean userbean = new UserBean("lallu@gmail.com","PriyaLatha", "lallu@123");

		try {
			int genId = daoImpl.createnewuser(userbean);
			assertNotNull(genId);
		} catch (Userexception e) {
				
		}
	}
	
	/*@Test
	public void testAddUserNull() {

		UserBean userbean = new UserBean("madhu@gmail.com", " ", "Madhu@123");

		try {
			int genId = daoImpl.createnewuser(userbean);
			assertNull(genId);
		} catch (Userexception e) {

		}
	}*/

	
	
}
