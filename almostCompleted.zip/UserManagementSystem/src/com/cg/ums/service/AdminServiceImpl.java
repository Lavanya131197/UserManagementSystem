package com.cg.ums.service;

import com.cg.ums.bean.AdminBean;
import com.cg.ums.dao.AdmindaoImpl;
import com.cg.ums.exception.Userexception;

public class AdminServiceImpl implements IAdminService{
	AdminBean adminbean = new AdminBean();
	AdmindaoImpl admindao = new AdmindaoImpl();

	public boolean validate(String email, String pass) throws Userexception {

		boolean res = true;
		adminbean.setEmail(email);
		adminbean.setPassword(pass);

		res = admindao.validate(adminbean);

		return res;
	}

}
