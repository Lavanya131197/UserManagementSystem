package com.cg.ums.dao;

import java.sql.SQLException;

import com.cg.ums.bean.AdminBean;

public interface IAdmindao {
	public boolean validate(AdminBean adminbean) throws SQLException;

}
